This directoty must be in /moodle/auth (Este directorio debe ir en /moodle/auth)

This software is licensed under GPL. For license details, see LICENSE.txt
