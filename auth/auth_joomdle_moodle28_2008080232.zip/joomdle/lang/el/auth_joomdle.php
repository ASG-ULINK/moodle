<?php 


$string['pluginname'] = 'Joomdle';
$string['pluginame_desc'] = 'Αυτή η μέθοδος χρησιμοποιεί τα web services του Joomdle για να γνωρίζει εάν ένας χρήστης έχει μια ενεργή συνεδρία στο in Joomla.Έκδοση 0.51';
$string['auth_joomdledescription'] = 'Αυτή η μέθοδος χρησιμοποιεί τα web services του Joomdle για να γνωρίζει εάν ένας χρήστης έχει μια ενεργή συνεδρία στο in Joomla.Έκδοση 0.51';

$string['joomla_sp_name'] = 'Joomdle';
$string['joomla_sp_description'] = 'Υπηρεσίες για ενσωμάτωση Joomla<br>';
$string['auth_joomla_url'] = 'URL του Joomla<br>';
$string['auth_joomla_url_desc'] = 'URL του server του Joomla<br>';
$string['auth_joomla_connection_method'] = 'Μέθοδος σύνδεσης<br>';
$string['auth_joomla_connection_method_description'] = 'Μέθοδος σύνδεσης που χρησιμοποιείται για τα Web Services<br>';
$string['auth_joomla_jomsocial_integration'] = 'Ενσωμάωση με το Jomsocial<br>';
$string['auth_joomla_jomsocial_integration_description'] = 'Ενσωμάτωση με το Jomsocial στο Joomla<br>';
$string['auth_joomla_jomsocial_activities'] = 'Δραστηριότητες του Jomsocial<br>';
$string['auth_joomla_jomsocial_activities_description'] = 'Προσθήκη δραστηριοτήτων του Jomsocial<br>';
$string['auth_joomla_jomsocial_groups'] = 'Δημιουργία ομάδων Jomsocial<br>';
$string['auth_joomla_jomsocial_groups_description'] = 'Δημιουργεία μιας ομάδας στο Jomsocial για κάθε μάθημα<br>';
$string['auth_joomla_jomsocial_groups_delete'] = 'Διαγραφή Ομάδων Jomsocial<br>';
$string['auth_joomla_jomsocial_groups_delete_description'] = 'Διαγραφή των ομάδων στο Jomsocial όταν διαγράφεται το μάθημα<br>';
$string['auth_joomla_group_discussion'] = 'Συζήτηση Ομάδας';
$string['auth_joomla_enrol_parents'] = 'Απόδοση ρόλων στους γονείς στα μαθήματα';
$string['auth_joomla_enrol_parents_description'] = 'Αυτόματη απόδοση ρόλων στους γονείς στα μαθήματα των παιδιών';
$string['auth_joomla_parent_role_id'] = 'ID του ρόλου του γονιού';
$string['auth_joomla_parent_role_id_description'] = 'ID Ρόλου του ρόλου του γονιού';
$string['auth_joomla_sync_to_joomla'] = 'Συγχρονίζει τους χρήστες με το Joomla';
$string['auth_joomla_sync_to_joomla_description'] = 'Συγχρονίζει τους νέους χρήστες και τις ενημερώσεις των προφίλ με το Joomla';
$string['auth_joomla_auto_sell'] = 'Auto courses<br>';
$string['auth_joomla_auto_sell_description'] = 'Δημιουργία/ενημέρωση/διαγραφή μαθημάτων στο κατάστημα του Joomla αυτό συμβαίνει στο Moodle<br>';
$string['auth_joomla_joomla_version'] = 'Έκδοση Joomla<br>';
$string['auth_joomla_version_description'] = 'Έκδοση Joomla<br>';
$string['auth_joomla_group_for_course'] = 'Ομάδα για το μάθημα';
?>
