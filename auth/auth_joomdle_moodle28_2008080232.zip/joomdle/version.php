<?php

$plugin->version  = 2008080232;
//$plugin->requires = 2010000000;
$plugin->requires = 2010112400;
$plugin->maturity = MATURITY_BETA;
$plugin->release = "0.95";

?>
