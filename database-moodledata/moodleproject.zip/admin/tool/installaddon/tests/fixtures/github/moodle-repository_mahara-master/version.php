<?php

$plugin->component = 'repository_mahara';
$plugin->version = 2014010100;
