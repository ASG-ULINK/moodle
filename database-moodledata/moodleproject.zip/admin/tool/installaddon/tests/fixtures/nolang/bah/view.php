<?php

echo 'Do not use hardcoded strings, provide the language pack';
