<?php
include("header.php");
?>
<p>
  <?=$_GET['message']?>


</p>
