Get latest version and detailed installation instructions on:
http://www.videowhisper.com/?p=Moodle+Video+Conference

Before installing, make sure your hosting environment meets all requirements. In addition to Moodle web hosting requirements, these applications demand a supported RTMP flash media server (Red5, Wowza, Adobe) where VideoWhisper rtmp side should be deployed.
http://www.videowhisper.com/?p=Requirements

If you're not hosting RTMP side with VideoWhisper.com managed plans/servers go to RTMP Application Setup for rtmp side installation instructions.
http://www.videowhisper.com/?p=RTMP+Applications