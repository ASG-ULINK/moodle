<?php

defined('MOODLE_INTERNAL') || die();

$separator = ',';

// fieldname => output string
$fields = array('displaytext' => 'Item text',
                'indent' => 'Indent',
                'itemoptional' => 'Type (0 - normal; 1 - optional; 2 - heading)',
                'duetime' => 'Due Time (timestamp)',
                'colour' => 'Colour (red; orange; green; purple; black)');
