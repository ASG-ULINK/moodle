<?php

defined('MOODLE_INTERNAL') || die();

$logs = array(
    array('module'=>'checklist', 'action'=>'view', 'mtable'=>'checklist', 'field'=>'name'),
    array('module'=>'checklist', 'action'=>'edit', 'mtable'=>'checklist', 'field'=>'name'),
    array('module'=>'checklist', 'action'=>'update checks', 'mtable'=>'checklist', 'field'=>'name'),
    array('module'=>'checklist', 'action'=>'complete', 'mtable'=>'checklist', 'field'=>'name'),
    array('module'=>'checklist', 'action'=>'report', 'mtable'=>'checklist', 'field'=>'name'),
);