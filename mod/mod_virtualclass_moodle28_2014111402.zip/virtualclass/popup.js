// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Settings used by the virtualclass module
 *
 * @package mod_virtualclass
 * @copyright  2014 Pinky Sharma
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or late
 **/

/* Open virtualclass in moodle page popup */
function virtualclass_openpopup(url, name, options, width, height) {
    if (width <= 100) {
        width = Math.round(screen.availWidth * width / 100);
    }
    if (height <= 100) {
        height = Math.round(screen.availHeight * height / 100);
    }
    options += ",width=" + width + ",height=" + height;
    if(window.windowobj && window.windowobj.closed == false){
        // Window already open
        windowobj.focus();
        return false;
    }else{
        windowobj = window.open(url, name, options, "");
    }

    if (!windowobj) {
        return;
    }
    if ((width == 100) && (height == 100)) {
        // Fullscreen
        windowobj.moveTo(0,0);
    }
    windowobj.focus();
    return windowobj;
}

/* Open url in popup and send data through post */
function virtualclass_online_popup(form) {
    var options = form.dataset.popupoption;
    var width = form.dataset.popupwidth;
    var height = form.dataset.popupheight;

    if (width <= 100) {
        width = Math.round(screen.availWidth * width / 100);
    }
    if (height <= 100) {
        height = Math.round(screen.availHeight * height / 100);
    }
    options += ",width=" + width + ",height=" + height;
    if(window.windowobj && window.windowobj.closed == false){
        windowobj.focus();
        return false;
    } else {
        windowobj = window.open('', 'popupVc', options);
    }

    form.target = 'popupVc';
    if (!windowobj) {
        return;
    }
    if ((width == 100) && (height == 100)) {
        // Fullscreen
        windowobj.moveTo(0,0);
    }
    windowobj.focus();
    return windowobj;
}
