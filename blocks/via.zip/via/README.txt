Version 2015012001


/* for more information on the version please see mod/via/version.php */
/* This plugin required Via 6.5 */


Procedure for a NEW installation of the Via plugin for Moodle 2.7 :
*********************************************************************


1 - Copy the Via folder into the mod folder of your moodle.

2 - You will need to contact SVIeSolutions (http://sviesolutions.com/) for the following access codes.
	- API's URL
	- Via ID (CieID)
	- Via API ID (ApiID)
	- You can test the connexion + validate that you are connected to the correct version of Via

	- Moodle admin ID
	- You can test the key


3 - For invoicing and statistics purposes you may create categories in Via and make them available in Moodle. Note these need to be created in Via to be available.  For these to be available, the moodle administrator must check the ckeckbox in the settings page, it is them possible to chose which categories will be avaiable and set one as default.

   
