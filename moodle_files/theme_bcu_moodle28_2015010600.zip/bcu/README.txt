HTML code for settings and block areas

Front page info block:

The html for this block should look like:
<div class="span9">
	<h4>Information</h4>
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
	</div>
	
	<div class="span3">
	<a href="#" class="submit">2013/14 Courses <i class="fa-chevron-right fa"></i></a>
</div>


Frontpage Marketing Block HTML structure

 	<div><img src="/someimageURL.jpg" class="marketimage"></div>
    <div class="internalmarket">
    <h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</h3>
    <a href="#" class="submit">My Home</a>
 	</div>
 	
 	
 Frontpage Secondary info Message HTML:
 
 <div class="span2 personpic">
		<div id="person" class="spn5">
		<img src="/urltoanimage.jpg" alt="person">
		</div>
		</div>
		
		<div class="span10">
		<h4>School of Jewelry</h4>
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
		<a href="#" class="submit">Learn more... <i class="fa-chevron-right fa"></i></a>
		</div>