Changes in version 1.0.2 (2015010600)
-------------------------------------
- FIX: Issue #98 - Fixed issue with language strings in language pack not being displayed to the user
- FIX: Issue #97 - Hardcoded language strings for changing the visibility of blocks and screen width (Thanks to André Yamin for providing the fix for this)
- FIX: Issue #96 - Added option to display the page load time
- FIX: Issue #95 - Fixed issue with displaying courseboxes when less than 2 in a row, merging and appearing as one row
- FIX: Issue #87 - Added file uploader for default course image when displaying the coursebox w/ renderer
- FIX: Issue #83 - Restructured the admin sections to be more consistent and easier to find settings
- FIX: Issue #80  - Added option to hide the title of the site from the homepage
- FIX: Issue #78 - Added extra height and padding to the top navbar to make it easier to use.